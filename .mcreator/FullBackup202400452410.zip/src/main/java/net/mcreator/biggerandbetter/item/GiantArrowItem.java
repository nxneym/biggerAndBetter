
package net.mcreator.biggerandbetter.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GiantArrowItem extends Item {
	public GiantArrowItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
